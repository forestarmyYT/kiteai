export const config = {
  max_threads: 100, // số luồng
  time_sleep: 15, //minutes
  code: "ehqJSY6f", //ref code
  number_ref: 10,
};
