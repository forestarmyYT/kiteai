import chalk from "chalk";

export const banner = `            
${chalk.yellow("Tool shared by FORESTARMY  telegram: https://t.me/forestarmy")}`;
