import axios from "axios";
import chalk from "chalk";

const urlChecking = "https://raw.githubusercontent.com/forestarmyYT/endpoint/main/endpoint";

export const checkBaseUrl = async () => {
  console.log(chalk.blue("Checking API..."));

  const result = await getBaseApi(urlChecking);
  if (result.endpoint) {
    console.log(chalk.green("No changes in the API!"));
    return result;
  }
};

const getBaseApi = async (url) => {
  try {
    const response = await axios.get(url);
    const content = response.data;

    if (content?.kite) {
      return { endpoint: content.kite, message: content.copyright };
    } else {
      return {
        endpoint: null,
        message:
          "If the API changes, please contact the Forestarmy Telegram group (https://t.me/forestarmy) for more information and updates! | Have any issues? Please contact: https://t.me/forestarmy",
      };
    }
  } catch (e) {
    return {
      endpoint: null,
      message:
        "If the API changes, please contact the Forestarmy Telegram group (https://t.me/forestarmy) for more information and updates! | Have any issues? Please contact: https://t.me/forestarmy",
    };
  }
};